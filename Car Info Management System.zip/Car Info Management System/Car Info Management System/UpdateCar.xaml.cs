﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using carbal;
using carentities;
using carexceptions;

namespace Car_Info_Management_System
{
    /// <summary>
    /// Interaction logic for Window5.xaml
    /// </summary>
    public partial class UpdateCar : Window
    {
        public UpdateCar()
        {
            InitializeComponent();
        }

        private void BtnUpdateCarDetails_Click(object sender, RoutedEventArgs e)
        {
            ModifyCar();
        }

        private void BtnSearchCarDetails_Click(object sender, RoutedEventArgs e)
        {
            FindCar();
        }

        private void BtnHomePage_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
        private void ModifyCar()
        {
            bool CarModified;
            try
            {

                Car objcar = new Car();

                objcar.ManufacturerName = cmbManufacturerName.Text;
                objcar.Model = txtModel.Text;
                objcar.Type = cmbCarType.Text;
                objcar.Engine = txtEngine.Text;
                objcar.BHP = Convert.ToInt32(txtBHP.Text);
                objcar.Transmission = cmbTransmissionType.Text;
                objcar.Mileage = Convert.ToInt32(txtMileage.Text);
                objcar.Seats = Convert.ToInt32(txtSeats.Text);
                objcar.AirBagDetails = txtAirbags.Text;
                objcar.BootSpace = Convert.ToInt32(txtBootSpace.Text);
                objcar.Price = Convert.ToDouble(txtPrice.Text);

                CarModified = CarBal.UpdateCarBal(objcar);


                if (CarModified)
                {
                    MessageBox.Show("Employee record added successfully.");
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be added.");
                }
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void FindCar()
        {

            string ManufacturerName;
            string Type;
            Car objcar = null;
            try
            {
                if (cmbManufacturerName.Text != "" && cmbCarType.Text != "")
                {
                    ManufacturerName = cmbManufacturerName.Text;
                    Type = cmbCarType.Text;
                    objcar = CarBal.SearchCarByNameBal(ManufacturerName);
                    objcar = CarBal.SearchCarByModelBal(Type);
                    if (objcar != null)
                    {
                        cmbManufacturerName.Text = objcar.ManufacturerName;
                        txtModel.Text = objcar.Model;
                        cmbCarType.Text = objcar.Type;
                        txtEngine.Text = objcar.Engine;
                        txtBHP.Text = objcar.BHP.ToString();
                        cmbTransmissionType.Text = objcar.Transmission;
                        txtMileage.Text = objcar.Mileage.ToString();
                        txtSeats.Text = objcar.Seats.ToString();
                        txtAirbags.Text = objcar.AirBagDetails;
                        txtBootSpace.Text = objcar.BootSpace.ToString();
                        txtPrice.Text = objcar.Price.ToString();
                    }
                    else
                        MessageBox.Show("Car not found");
                }
                else
                {
                    MessageBox.Show("Please Enter ManufacturerName and Type to Search");
                }
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

    }
}
   
