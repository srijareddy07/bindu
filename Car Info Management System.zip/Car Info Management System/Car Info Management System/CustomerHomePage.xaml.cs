﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Car_Info_Management_System
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class CustomerHomePage : Window
    {
        public CustomerHomePage()
        {
            InitializeComponent();
        }

        private void BtnGetCarDetails_Click(object sender, RoutedEventArgs e)
        {
            GetAllCars getallcars = new GetAllCars();
            getallcars.Show();
            this.Close();
        }

        private void BtnSearchCar_Click(object sender, RoutedEventArgs e)
        {
            SearchCar searchcar = new SearchCar();
            searchcar.Show();
            this.Close();
        }

        private void BtnHomePage_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
