﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using carbal;
using carentities;
using carexceptions;

namespace Car_Info_Management_System
{
    /// <summary>
    /// Interaction logic for Window3.xaml
    /// </summary>
    public partial class AddCar : Window
    {
        public AddCar()
        {
            InitializeComponent();
        }
        private void BtnAddCarDetails_Click(object sender, RoutedEventArgs e)
        {
            InsertCar();
        }
        public void InsertCar()
        {
           
            bool CarAdded;
            try
            {

                //
                Car objcar = new Car();


                objcar.ManufacturerName = cmbManufacturerName.Text;
                objcar.Model = txtModel.Text;
                objcar.Type = cmbCarType.Text;
                objcar.Engine = txtEngine.Text;
                objcar.BHP = Convert.ToInt32(txtBHP.Text);
                objcar.Transmission = cmbTransmission.Text;
                objcar.Mileage = Convert.ToInt32(txtMileage.Text);
                objcar.Seats = Convert.ToInt32(txtSeats.Text);
                objcar.AirBagDetails = txtAirbags.Text;
                objcar.BootSpace = Convert.ToInt32(txtBootSpace.Text);
                objcar.Price = Convert.ToDouble(txtPrice.Text);

                CarAdded = CarBal.AddCarBal(objcar);


                if (CarAdded)
                {
                    MessageBox.Show("Employee record added successfully.");
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be added.");
                }
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BtnHomePage_Click(object sender, RoutedEventArgs e)
        {
            Administrator administrator = new Administrator();
            administrator.Show();
            this.Close();
        }

    }
}
