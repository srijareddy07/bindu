﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Car_Info_Management_System
{
    /// <summary>
    /// Interaction logic for GetAllCars.xaml
    /// </summary>
    public partial class GetAllCars : Window
    {
        public GetAllCars()
        {
            InitializeComponent();
        }

        private void BtnHomePage_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Show();
        }

        private void BtnGetAllCars_Click(object sender, RoutedEventArgs e)
        {
            GetAllCars getallcars = new GetAllCars();
            getallcars.Show();
            this.Close();
        }
    }
}
