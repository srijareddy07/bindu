﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using carentities;
using carexceptions;
using System.Configuration;

namespace cardal
{
    public class CarDal
    {
        SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CARConnectionString"].ConnectionString);
        SqlDataReader objDr;
        public bool AddCarDal(Car car)
        {
            bool CarAdded = false;
            try
            {

                SqlCommand objCom = new SqlCommand("[46008229].AddCar", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", car.Model);
                SqlParameter objSqlParam_ManufacturerName = new SqlParameter("@ManufacturerId", car.ManufacturerName);
                SqlParameter objSqlParam_Type = new SqlParameter("@TypeId", car.Type);
                SqlParameter objSqlParam_Engine = new SqlParameter("@Engine", car.Engine);
                SqlParameter objSqlParam_BHP = new SqlParameter("@BHP", car.BHP);
                SqlParameter objSqlParam_Transmission = new SqlParameter("@TransmissionId", car.Transmission);
                SqlParameter objSqlParam_Mileage = new SqlParameter("@Mileage", car.Mileage);
                SqlParameter objSqlParam_Seats = new SqlParameter("@Seats", car.Seats);
                SqlParameter objSqlParam_AirBagDetails = new SqlParameter("@AirBagDetails",car.AirBagDetails);
                SqlParameter objSqlParam_BootSpace = new SqlParameter("@BootSpace", car.BootSpace);
                SqlParameter objSqlParam_Price = new SqlParameter("@Price", car.Price);
    
                objCom.Parameters.Add(objSqlParam_Model);
                objCom.Parameters.Add(objSqlParam_ManufacturerName);
                objCom.Parameters.Add(objSqlParam_Type);
                objCom.Parameters.Add(objSqlParam_Engine);
                objCom.Parameters.Add(objSqlParam_BHP);
                objCom.Parameters.Add(objSqlParam_Transmission);
                objCom.Parameters.Add(objSqlParam_Mileage);
                objCom.Parameters.Add(objSqlParam_Seats);
                objCom.Parameters.Add(objSqlParam_AirBagDetails);
                objCom.Parameters.Add(objSqlParam_BootSpace);
                objCom.Parameters.Add(objSqlParam_Price);
 
                objCon.Open();
                objCom.ExecuteNonQuery();
                CarAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return CarAdded;
        }
        public bool DeleteCarDal(string model)
        {
            bool CarDeleted = false;
            SqlConnection objCon = null;
            try
            {
                SqlCommand objCom = new SqlCommand("[46008229].DeleteCar", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", model);
                
                objCom.Parameters.Add(objSqlParam_Model);
                
                objCon.Open();
                objCom.ExecuteNonQuery();
                CarDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return CarDeleted;
        }
        public bool UpdateCarDal(Car car)
        {
            bool CarUpdated = false;
            try
            {
                SqlCommand objCom = new SqlCommand("[46008229].UpdateCar", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", car.Model);
                SqlParameter objSqlParam_ManufacturerName = new SqlParameter("@ManufacturerId", car.ManufacturerName);
                SqlParameter objSqlParam_Type = new SqlParameter("@TypeId", car.Type);
                SqlParameter objSqlParam_Engine = new SqlParameter("@Engine", car.Engine);
                SqlParameter objSqlParam_BHP = new SqlParameter("@BHP", car.BHP);
                SqlParameter objSqlParam_Transmission = new SqlParameter("@TransmissionId", car.Transmission);
                SqlParameter objSqlParam_Mileage = new SqlParameter("@Mileage", car.Mileage);
                SqlParameter objSqlParam_Seats = new SqlParameter("@Seats", car.Seats);
                SqlParameter objSqlParam_AirBagDetails = new SqlParameter("@AirBagDetails", car.AirBagDetails);
                SqlParameter objSqlParam_BootSpace = new SqlParameter("@BootSpace", car.BootSpace);
                SqlParameter objSqlParam_Price = new SqlParameter("@Price", car.Price);

                //
                objCom.Parameters.Add(objSqlParam_Model);
                objCom.Parameters.Add(objSqlParam_ManufacturerName);
                objCom.Parameters.Add(objSqlParam_Type);
                objCom.Parameters.Add(objSqlParam_Engine);
                objCom.Parameters.Add(objSqlParam_BHP);
                objCom.Parameters.Add(objSqlParam_Transmission);
                objCom.Parameters.Add(objSqlParam_Mileage);
                objCom.Parameters.Add(objSqlParam_Seats);
                objCom.Parameters.Add(objSqlParam_AirBagDetails);
                objCom.Parameters.Add(objSqlParam_BootSpace);
                objCom.Parameters.Add(objSqlParam_Price);

                
                objCon.Open();
                objCom.ExecuteNonQuery();
                CarUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return CarUpdated;
        }
        
        public Car SearchCarByModelDal(string model)
        {
            Car car = null;
            try
            {
                objCon.Open();
                SqlCommand objCom = new SqlCommand("[46008229].SearchCarByModel", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCom.Parameters.AddWithValue("@Model", model);
                //
                objDr = objCom.ExecuteReader();
                objDr.Read();
                if (objDr.HasRows)
                {
                    car = new Car();
                    car.Model = objDr[0].ToString();
                    car.ManufacturerName = objDr[1].ToString();
                    car.Type = objDr[2].ToString();
                    car.Engine = objDr[3].ToString();
                    car.BHP = Convert.ToInt32(objDr[4].ToString());
                    car.Transmission = objDr[5].ToString();
                    car.Mileage = Convert.ToInt32(objDr[6].ToString());
                    car.AirBagDetails = objDr[7].ToString();
                    car.BootSpace = Convert.ToInt32(objDr[8].ToString());
                    car.Seats = Convert.ToInt32(objDr[9].ToString());
                    car.Price = Convert.ToDouble(objDr[10].ToString());
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return car;
        }
        public Car SearchCarByNameDal(string name)
        {
            Car car = null;
            try
            {
                objCon.Open();
                SqlCommand objCom = new SqlCommand("[46008229].SearchCarByName", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                objCom.Parameters.AddWithValue("@name", name);

                objDr = objCom.ExecuteReader();
                objDr.Read();
                if (objDr.HasRows)
                {
                    car = new Car();
                    //
                    car.Model = objDr[1].ToString();
                    car.ManufacturerName = objDr[2].ToString();
                    car.Type = objDr[3].ToString();
                    car.Engine = objDr[4].ToString();
                    car.BHP = Convert.ToInt32(objDr[5].ToString());
                    car.Transmission = objDr[6].ToString();
                    car.Mileage = Convert.ToInt32(objDr[7].ToString());
                    car.AirBagDetails = objDr[8].ToString();
                    car.BootSpace = Convert.ToInt32(objDr[9].ToString());
                    car.Seats = Convert.ToInt32(objDr[10].ToString());
                    car.Price = Convert.ToDouble(objDr[11].ToString());
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return car;
        }
        public List<Car> ListAllCarsDal(string name, string type)
        {
            List<Car> Cars = new List<Car>();
            try
            {
                objCon.Open();
                SqlCommand objCom = new SqlCommand("[46008229].ListCars", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCom.Parameters.AddWithValue("@name", name);
                objCom.Parameters.AddWithValue("@type", type);
                //
                objDr = objCom.ExecuteReader();
                if (objDr.HasRows)
                {
                    while (objDr.Read())
                    {
                        Car car = new Car();
                        car.ManufacturerName = objDr[0].ToString();
                        car.Model = objDr[1].ToString();
                        car.Type = objDr[2].ToString();
                        car.Price = Convert.ToDouble(objDr[3].ToString());
                        Cars.Add(car);
                    }
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return Cars;
        }

    }
}
